// cPanel / Passenger startup file — starts the Next.js server from ./.next
// Settings (MONGO_URI, JWT_SECRET, …) come from Setup Node.js App → Environment variables; a .env file next
// to this one is read too, without overriding those.
const fs = require('node:fs');
const path = require('node:path');
const { createServer } = require('node:http');

// The site reads public/ and uploads/ relative to the working directory
process.chdir(__dirname);
const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile))
  for (const line of fs.readFileSync(envFile, 'utf8').split(/\r?\n/)) {
    const m = line.match(/^\s*([A-Z0-9_]+)\s*=\s*(.*)\s*$/);
    if (m && process.env[m[1]] === undefined) process.env[m[1]] = m[2].replace(/^(['"])(.*)\1$/, '$2');
  }
process.env.NODE_ENV = 'production';
process.env.NEXT_PUBLIC_SITE_URL = process.env.NEXT_PUBLIC_SITE_URL || "http://poo.multisports.com.bd";
// Dashboard uploads live next to app.js, outside .next, so replacing .next on an update keeps them
process.env.UPLOAD_DIR = process.env.UPLOAD_DIR || path.join(__dirname, 'uploads');
fs.mkdirSync(process.env.UPLOAD_DIR, { recursive: true });

for (const key of ['MONGO_URI', 'JWT_SECRET'])
  if (!process.env[key])
    console.error(
      '✖ ' + key + ' is not set — add it in Setup Node.js App → Environment variables. If it is there, a value with a " (quote),\n' +
        '  $ or ` in it breaks ALL the variables: remove those quotes, or move that variable into a .env file next to app.js'
    );

// Passenger passes PORT (sometimes a socket path, so it isn't parsed as a number)
const port = process.env.PORT || 3000;

// This upload was built with one Next.js version and "Run NPM Install" installs it on the server. Until both match
// the site can't work (its scripts and styles fail), so visitors get a short "updating" page and the log says why.
// The check repeats every few seconds: as soon as NPM Install has put the right version in place this process exits,
// and Passenger starts the real site on the next visit — no Restart click needed.
const builtWith = readText(path.join(__dirname, '.next', 'NEXT_VERSION'));
const nextReady = () => {
  const installed = installedNext();
  return Boolean(installed) && (!builtWith || installed === builtWith);
};
if (!nextReady()) {
  const installed = installedNext();
  console.error(
    '✖ ' + (installed ? 'Next.js ' + installed + ' is installed, but this upload needs ' + builtWith : 'Next.js is not installed') +
      ' — Setup Node.js App → Run NPM Install and wait until it finishes. The site starts by itself afterwards.'
  );
  let checkedAt = 0;
  createServer((req, res) => {
    let ready = false;
    if (Date.now() - checkedAt > 5000) {
      checkedAt = Date.now();
      ready = nextReady();
    }
    res.writeHead(503, {
      'Content-Type': 'text/html; charset=utf-8',
      'Retry-After': '30',
      'Cache-Control': 'no-store',
      'X-Update-Status': installed ? 'npm-install-needed' : 'next-not-installed',
    });
    res.end(
      '<!doctype html><meta charset="utf-8"><meta name="viewport" content="width=device-width,initial-scale=1">' +
        '<meta http-equiv="refresh" content="30"><title>Updating</title>' +
        '<div style="font:16px/1.5 system-ui,sans-serif;max-width:32rem;margin:20vh auto;padding:0 1rem;text-align:center">' +
        '<h1 style="font-size:1.4rem">The website is being updated</h1><p>Please try again in a few minutes.</p></div>',
      () => {
        if (!ready) return;
        console.log('> Next.js ' + installedNext() + ' is installed now — starting the website');
        process.exit(0); // Passenger starts a fresh process (the real site) on the next request
      }
    );
  }).listen(port);
} else {
  start();
}

// Read from disk each time (not require's cache), so an install made while this process runs is seen
function installedNext() {
  try {
    return JSON.parse(fs.readFileSync(require.resolve('next/package.json'), 'utf8')).version;
  } catch {
    return '';
  }
}

function readText(file) {
  try {
    return fs.readFileSync(file, 'utf8').trim();
  } catch {
    return '';
  }
}

function start() {
  const next = require('next');
  const app = next({ dev: false, dir: __dirname });
  const handle = app.getRequestHandler();
  app
    .prepare()
    .then(() =>
      createServer(async (req, res) => {
        try {
          await handle(req, res);
        } catch (err) {
          // One bad request must not take the whole site down
          console.error('Error handling', req.url, err);
          if (!res.headersSent) res.statusCode = 500;
          res.end('Internal server error');
        }
      })
        .once('error', (err) => {
          if (err.code === 'EADDRINUSE')
            console.error(
              '✖ Port ' + port + ' is in use — the site is probably already running. Don\'t start it with "Run JS script → start";\n' +
                '  cPanel starts app.js by itself: just click Restart in Setup Node.js App and open the site.'
            );
          else console.error(err);
          process.exit(1);
        })
        .listen(port, () => console.log('> USACC website ready on ' + port))
    )
    .catch((err) => {
      console.error(err);
      process.exit(1);
    });
}
