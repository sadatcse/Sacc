// Checks that this server can reach MongoDB Atlas. In cPanel → Terminal (inside the app folder):
//   node check-db.js
const fs = require('node:fs');
const path = require('node:path');
const dns = require('node:dns').promises;
const net = require('node:net');

const envFile = path.join(__dirname, '.env');
if (fs.existsSync(envFile) && typeof process.loadEnvFile === 'function') process.loadEnvFile(envFile);
const uri = process.env.MONGO_URI;
if (!uri) {
  console.log('✖ MONGO_URI is not set. Add it in Setup Node.js App → Environment variables (or .env), then run:');
  console.log('  MONGO_URI="…" node check-db.js');
  process.exit(1);
}
const host = new URL(uri.replace(/^mongodb\+srv:/, 'http:')).hostname;

const tcp = (h, port) =>
  new Promise((resolve) => {
    const s = net.connect({ host: h, port, timeout: 8000 });
    s.on('connect', () => (s.destroy(), resolve('open')));
    s.on('timeout', () => (s.destroy(), resolve('TIMEOUT')));
    s.on('error', (e) => resolve(e.code));
  });

(async () => {
  try {
    const ip = await fetch('https://api.ipify.org').then((r) => r.text());
    console.log('This server connects from IP:', ip, '→ this IP (or 0.0.0.0/0) must be in Atlas → Network Access');
  } catch {
    console.log('(could not look up this server\'s public IP)');
  }
  let hosts = [host];
  try {
    hosts = (await dns.resolveSrv('_mongodb._tcp.' + host)).map((r) => r.name);
    console.log('✔ DNS ok —', hosts.length, 'Atlas servers found');
  } catch (e) {
    console.log('✖ DNS lookup of', host, 'failed:', e.code, '— the host blocks DNS SRV lookups; ask them to allow it');
  }
  let open = 0;
  for (const h of hosts) {
    const r = await tcp(h, 27017);
    if (r === 'open') open += 1;
    console.log(r === 'open' ? '✔' : '✖', h + ':27017', r);
  }
  if (!open) {
    console.log('\n✖ Port 27017 is blocked from this server. Ask your hosting support:');
    console.log('  "Please allow outgoing TCP connections on port 27017 to *.mongodb.net (MongoDB Atlas) for my account."');
    process.exit(1);
  }
  try {
    const mongoose = require('mongoose');
    await mongoose.connect(uri, { serverSelectionTimeoutMS: 15000 });
    console.log('\n✔ Connected to MongoDB — the website can reach the database. Restart the app in Setup Node.js App.');
    await mongoose.disconnect();
  } catch (e) {
    const reasons = [...(e?.reason?.servers?.values?.() || [])].map((s) => s.error?.message).filter(Boolean);
    console.log('\n✖ Port is open but connecting failed:', reasons[0] || e.message);
    if (/auth/i.test(reasons[0] || e.message)) console.log('  → the username or password in MONGO_URI is wrong (Atlas → Database Access)');
    process.exit(1);
  }
})();
