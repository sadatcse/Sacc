var R=require("./chunks/[turbopack]_runtime.js")("server/middleware.js")
R.c("server/chunks/[externals]__12w_i1wnpawwb._.js")
R.c("server/chunks/[root-of-the-server]__1d5_gphav_s3a._.js")
R.m(15838)
module.exports=R.m(15838).exports
