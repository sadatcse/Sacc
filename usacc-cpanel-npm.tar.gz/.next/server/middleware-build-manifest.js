globalThis.__BUILD_MANIFEST = {
  "pages": {
    "/_app": []
  },
  "devFiles": [],
  "polyfillFiles": [
    "static/chunks/0cz1d0mv5g_q7.js"
  ],
  "lowPriorityFiles": [
    "static/gzn-xp-Va6i_KOdtx3cR9/_buildManifest.js",
    "static/gzn-xp-Va6i_KOdtx3cR9/_ssgManifest.js",
    "static/gzn-xp-Va6i_KOdtx3cR9/_clientMiddlewareManifest.js"
  ],
  "rootMainFiles": [
    "static/chunks/1ckvzn7sfprko.js",
    "static/chunks/2r4s4h5xul1n-.js",
    "static/chunks/0ipqvmgiypu2f.js",
    "static/chunks/37lnsi-53udmy.js",
    "static/chunks/turbopack-2c3mg3r-05n1w.js"
  ],
  "rootMainFilesTree": {},
  "pagesChunkGroupBootstrapParams": {
    "/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_not-found/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/_global-error/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/about/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/account/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/account/alumni/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/account/certificates/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/account/members/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/account/payments/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/account/security/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/alumni/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/alumni/[slug]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/certificates/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/certificates/[code]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/contact/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/about/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/activity/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/alumni/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/certificates/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/contact-messages/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/event-certificates/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/event-certificates/[id]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/executives/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/gallery/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/login-history/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/members/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/membership/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/news/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/news/[id]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/news/new/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/payment-methods/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/payments/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/profile/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/settings/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/traffic/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/dashboard/users/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/executives/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/executives/[slug]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/gallery/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/join/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/legal/appprivacypolicy/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/legal/cookiepolicy/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/legal/refundpolicy/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/legal/termsofuse/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/login/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/news/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/news/[slug]/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    },
    "/register/page": {
      "otherChunks": [
        "static/chunks/1ckvzn7sfprko.js",
        "static/chunks/2r4s4h5xul1n-.js",
        "static/chunks/0ipqvmgiypu2f.js",
        "static/chunks/37lnsi-53udmy.js"
      ],
      "runtimeModuleIds": [
        94553
      ]
    }
  },
  "chunkLoadingGlobal": "TURBOPACK"
};
