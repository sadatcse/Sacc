module.exports=[99781,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_contact_%5Bid%5D_route_actions_1fwdxv-x-s67z.js.map