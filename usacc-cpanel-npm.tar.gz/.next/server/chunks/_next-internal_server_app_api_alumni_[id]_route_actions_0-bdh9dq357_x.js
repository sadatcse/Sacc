module.exports=[72538,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_alumni_%5Bid%5D_route_actions_0-bdh9dq357_x.js.map