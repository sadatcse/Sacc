module.exports=[97599,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_gallery_%5Bid%5D_route_actions_1sbikz27xsu9y.js.map