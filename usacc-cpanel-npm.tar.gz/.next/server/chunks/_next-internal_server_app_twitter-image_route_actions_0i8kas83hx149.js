module.exports=[62340,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_twitter-image_route_actions_0i8kas83hx149.js.map