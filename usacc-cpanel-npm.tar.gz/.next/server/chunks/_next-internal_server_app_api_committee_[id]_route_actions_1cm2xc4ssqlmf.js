module.exports=[66905,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_committee_%5Bid%5D_route_actions_1cm2xc4ssqlmf.js.map