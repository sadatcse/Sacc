module.exports=[43977,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_certificates_%5Bid%5D_route_actions_0wpmypghu6gsa.js.map