module.exports=[70828,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_executives_%5Bid%5D_alumni_route_actions_07-tpn-x_soq-.js.map