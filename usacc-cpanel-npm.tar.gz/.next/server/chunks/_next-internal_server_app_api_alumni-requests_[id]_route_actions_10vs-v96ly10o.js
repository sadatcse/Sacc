module.exports=[65883,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_alumni-requests_%5Bid%5D_route_actions_10vs-v96ly10o.js.map