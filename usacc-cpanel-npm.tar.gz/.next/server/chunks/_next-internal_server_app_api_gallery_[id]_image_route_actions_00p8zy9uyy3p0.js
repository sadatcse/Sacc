module.exports=[37612,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_gallery_%5Bid%5D_image_route_actions_00p8zy9uyy3p0.js.map