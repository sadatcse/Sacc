module.exports=[8297,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_certificate-events_route_actions_13eo6kqxef24r.js.map