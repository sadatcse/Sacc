module.exports=[66070,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_settings_%5Bkey%5D_route_actions_0d212dnd8-rs8.js.map