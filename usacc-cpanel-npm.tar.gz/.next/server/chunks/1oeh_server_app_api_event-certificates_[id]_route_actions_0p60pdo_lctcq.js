module.exports=[33048,s=>{"use strict";s.s([])}];

//# sourceMappingURL=1oeh_server_app_api_event-certificates_%5Bid%5D_route_actions_0p60pdo_lctcq.js.map