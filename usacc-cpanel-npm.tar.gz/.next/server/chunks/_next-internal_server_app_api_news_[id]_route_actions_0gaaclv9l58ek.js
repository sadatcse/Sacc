module.exports=[56155,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_news_%5Bid%5D_route_actions_0gaaclv9l58ek.js.map