module.exports=[30614,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_payments_%5Bid%5D_remind_route_actions_04c7judsuq0-k.js.map