module.exports=[92648,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.c,{})}])},71436,function(a){a.n(a.i(92648))}];

//# sourceMappingURL=app_alumni_loading_jsx_0yqlb5qztm1ij._.js.map