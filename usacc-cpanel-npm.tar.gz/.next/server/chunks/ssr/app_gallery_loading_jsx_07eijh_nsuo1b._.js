module.exports=[56944,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.m,{label:"Loading photos…",chips:!1,count:9})}])},34772,function(a){a.n(a.i(56944))}];

//# sourceMappingURL=app_gallery_loading_jsx_07eijh_nsuo1b._.js.map