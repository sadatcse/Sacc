module.exports=[2013,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.H,{sidebar:!1})}])},31027,function(a){a.n(a.i(2013))}];

//# sourceMappingURL=app_executives_%5Bslug%5D_loading_jsx_0l6x0zdhkh3-f._.js.map