module.exports=[22640,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.m,{label:"Loading news…"})}])},89793,function(a){a.n(a.i(22640))}];

//# sourceMappingURL=app_news_loading_jsx_0wc__aljm8lsp._.js.map