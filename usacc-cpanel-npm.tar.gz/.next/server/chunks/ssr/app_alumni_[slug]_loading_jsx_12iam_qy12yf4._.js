module.exports=[82898,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.H,{label:"Loading alumni profile…"})}])},43062,function(a){a.n(a.i(82898))}];

//# sourceMappingURL=app_alumni_%5Bslug%5D_loading_jsx_12iam_qy12yf4._.js.map