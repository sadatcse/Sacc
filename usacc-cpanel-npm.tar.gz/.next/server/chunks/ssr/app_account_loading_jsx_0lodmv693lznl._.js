module.exports=[73817,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.W,{cards:2})}])},99547,function(a){a.n(a.i(73817))}];

//# sourceMappingURL=app_account_loading_jsx_0lodmv693lznl._.js.map