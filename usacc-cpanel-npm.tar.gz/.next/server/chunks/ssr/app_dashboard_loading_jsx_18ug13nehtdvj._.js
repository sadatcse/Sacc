module.exports=[87885,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.b,{})}])},29315,function(a){a.n(a.i(87885))}];

//# sourceMappingURL=app_dashboard_loading_jsx_18ug13nehtdvj._.js.map