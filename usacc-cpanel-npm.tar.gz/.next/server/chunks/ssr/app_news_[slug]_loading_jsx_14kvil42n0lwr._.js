module.exports=[46236,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.Q,{})}])},21115,function(a){a.n(a.i(46236))}];

//# sourceMappingURL=app_news_%5Bslug%5D_loading_jsx_14kvil42n0lwr._.js.map