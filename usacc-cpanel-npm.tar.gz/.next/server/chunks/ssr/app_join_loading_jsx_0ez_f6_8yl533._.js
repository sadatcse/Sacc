module.exports=[64320,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.l,{label:"Loading the form…",panels:2})}])},76833,function(a){a.n(a.i(64320))}];

//# sourceMappingURL=app_join_loading_jsx_0ez_f6_8yl533._.js.map