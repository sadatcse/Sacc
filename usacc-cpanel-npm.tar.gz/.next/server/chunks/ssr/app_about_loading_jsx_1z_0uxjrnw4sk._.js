module.exports=[22715,a=>{"use strict";var b=a.i(7997),c=a.i(51589);a.s(["default",0,function(){return(0,b.jsx)(c.l,{label:"Loading about page…"})}])},19960,function(a){a.n(a.i(22715))}];

//# sourceMappingURL=app_about_loading_jsx_1z_0uxjrnw4sk._.js.map