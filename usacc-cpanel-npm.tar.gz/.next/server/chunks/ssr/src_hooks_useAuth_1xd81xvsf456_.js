module.exports=[80203,a=>{"use strict";var b=a.i(72131),c=a.i(45072);a.s(["f",0,function(){let a=(0,b.useContext)(c.Y);if(!a)throw Error("useAuth must be used inside <AuthProvider>");return a}])}];

//# sourceMappingURL=src_hooks_useAuth_1xd81xvsf456_.js.map