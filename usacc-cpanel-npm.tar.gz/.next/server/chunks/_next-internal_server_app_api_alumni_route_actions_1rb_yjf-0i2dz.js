module.exports=[19714,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_alumni_route_actions_1rb_yjf-0i2dz.js.map