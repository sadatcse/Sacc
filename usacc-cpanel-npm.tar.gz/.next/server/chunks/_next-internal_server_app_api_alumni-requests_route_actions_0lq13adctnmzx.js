module.exports=[96933,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_alumni-requests_route_actions_0lq13adctnmzx.js.map