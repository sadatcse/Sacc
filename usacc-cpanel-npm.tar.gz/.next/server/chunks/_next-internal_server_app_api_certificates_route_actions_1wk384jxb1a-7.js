module.exports=[38432,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_certificates_route_actions_1wk384jxb1a-7.js.map