module.exports=[35980,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_opengraph-image_route_actions_1n32_cshpygg5.js.map