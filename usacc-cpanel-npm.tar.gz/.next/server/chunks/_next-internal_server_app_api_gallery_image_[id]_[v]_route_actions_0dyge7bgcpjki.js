module.exports=[65523,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_gallery_image_%5Bid%5D_%5Bv%5D_route_actions_0dyge7bgcpjki.js.map