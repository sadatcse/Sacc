module.exports=[54862,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_uploads_route_actions_0w1331t5nhh2j.js.map