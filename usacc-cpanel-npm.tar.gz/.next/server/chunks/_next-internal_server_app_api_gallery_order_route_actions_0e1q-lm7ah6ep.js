module.exports=[36717,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_gallery_order_route_actions_0e1q-lm7ah6ep.js.map