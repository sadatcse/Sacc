module.exports=[34499,s=>{"use strict";s.s([])}];

//# sourceMappingURL=_next-internal_server_app_api_gallery_news_route_actions_206g_jyveuqq3.js.map