var R=require("./chunks/[turbopack]_runtime.js")("server/instrumentation.js")
R.c("server/chunks/_0c0bledo5qpxr._.js")
R.m(54163)
module.exports=R.m(54163).exports
